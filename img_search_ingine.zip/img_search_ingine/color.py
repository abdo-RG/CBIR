import cv2
import os
import pandas as pd
import numpy as np
from tqdm import tqdm
import csv

dataset = 'baseofimages'

def histogram(image, mask):
		
    hist = cv2.calcHist([image], [0, 1, 2], mask, (8, 12, 3),[0, 180, 0, 256, 0, 256])
    histf = cv2.normalize(hist,hist).flatten()

    return histf

def extract_features(chemin_image):
    features = []
    image = cv2.imread(chemin_image)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    (h, w) = image.shape[:2]
    (cX, cY) = (int(w * 0.5), int(h * 0.5))
    segments = [(0, cX, 0, cY), (cX, w, 0, cY), (cX, w, cY, h),(0, cX, cY, h)]
    (axesX, axesY) = (int(w * 0.75) // 2, int(h * 0.75) // 2)
    ellipMask = np.zeros(image.shape[:2], dtype = "uint8")
    cv2.ellipse(ellipMask, (cX, cY), (axesX, axesY), 0, 0, 360, 255, -1)
    for (startX, endX, startY, endY) in segments:
        cornerMask = np.zeros(image.shape[:2], dtype = "uint8")
        cv2.rectangle(cornerMask, (startX, startY), (endX, endY), 255, -1)
        cornerMask = cv2.subtract(cornerMask, ellipMask)
        hist = histogram(image, cornerMask)
        features.extend(hist)
    hist = histogram(image, ellipMask)
    features.extend(hist)
	# return the feature vector
    return features


def chi2_distance(histA, histB, eps = 1e-10):
		d = 0.5 * np.sum([((a - b) ** 2) / (a + b + eps) for (a, b) in zip(histA, histB)])
		return d

def Apprentissage(datasetpath):
    histos_dict = {}
    for img in tqdm(os.listdir(datasetpath)):
        histos_dict[img] = extract_features(datasetpath+'/'+img)
    
    df = pd.DataFrame(histos_dict)
    index_fichier = df.to_csv('histogrmme2.csv')
    return index_fichier

# Apprentissage(dataset)

df = pd.read_csv('histogrmme2.csv')

def Chercher(chemin_req):
    dist_dict = {}
    req_histo = extract_features(chemin_req)
    df[chemin_req] = req_histo
    for img in df.columns:
        dist_dict[img]=chi2_distance(df[chemin_req],df[img])

    dist_dict = dict(sorted(dist_dict.items(), key=lambda item: item[1]))

    return dist_dict

def Affichage(dist_dict):
    combiner = np.ones((300*2,300*4,3),dtype=np.uint8)
    p_h=0
    p_v=0
    for k in range(8):
        if k < 4 :
            combiner[:300,p_h:p_h+300] = cv2.resize(cv2.imread(dataset+'/'+list(dist_dict.keys())[k+1]),(300,300))
            p_h+=300
        else:
            combiner[300:600,p_v:p_v+300] = cv2.resize(cv2.imread(dataset+'/'+list(dist_dict.keys())[k+1]),(300,300))
            p_v+=300
    img_req = cv2.imread(dataset+'/'+list(dist_dict.keys())[1])
    cv2.imshow('Image_reqeutte',img_req)
    cv2.imshow('Resultat',combiner)
    cv2.waitKey(0)



def main():
    path_req=str(input("Chemin d image requete: "))
    dist_dictt = Chercher(rf'{path_req}')
    Affichage(dist_dictt)


if __name__ == '__main__':
    main()
