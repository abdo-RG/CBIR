from skimage import feature
import numpy as np
import cv2
import os
import pandas as pd
import numpy as np
from tqdm import tqdm

dataset = 'txtredataset'


def texture_descriptor(image_path,radius=2, sampling_pixels=4):
    gray_img = cv2.imread(image_path,cv2.IMREAD_GRAYSCALE)
    lbp = feature.local_binary_pattern(gray_img/256, 8, radius, method="uniform")
    (hist, _) = np.histogram(lbp.ravel(), bins=np.arange(0, sampling_pixels + 3), range=(0, sampling_pixels + 2))

    # normalization
    hist = hist.astype("float")
    hist /= (hist.sum() + 1e-6)
    # return the histogram of Local Binary Patterns
    return hist


def Euclidean_distance(p, q):
    dist = np.sqrt(np.sum(np.square(p-q)))
    return dist

def Apprentissage(datasetpath):
    Hu_mom_dict = {}
    for img in tqdm(os.listdir(datasetpath)):
        Hu_mom_dict[img] = texture_descriptor(datasetpath+'/'+img)
        
    
    df = pd.DataFrame(Hu_mom_dict)
    index_fichier = df.to_csv('LBP.csv')
    return index_fichier

# Apprentissage(dataset)

df = pd.read_csv('LBP.csv')

def Chercher(chemin_req):
    dist_dict = {}
    req_histo = texture_descriptor(chemin_req)
    df[chemin_req] = req_histo
    for img in df.columns:
        dist_dict[img]=Euclidean_distance(df[chemin_req],df[img])

    dist_dict = dict(sorted(dist_dict.items(), key=lambda item: item[1]))
    
    return dist_dict


def Affichage(dist_dict):
    combiner = np.ones((200*2,200*4,3),dtype=np.uint8)
    p_h=0
    p_v=0
    for k in range(8):
        if k < 4 :
            combiner[:200,p_h:p_h+200] = cv2.resize(cv2.imread(dataset+'/'+list(dist_dict.keys())[k+1]),(200,200))
            p_h+=200
        else:
            combiner[200:400,p_v:p_v+200] = cv2.resize(cv2.imread(dataset+'/'+list(dist_dict.keys())[k+1]),(200,200))
            p_v+=200
    img_req = cv2.imread(dataset+'/'+list(dist_dict.keys())[1])
    cv2.imshow('Image_reqeutte',img_req)
    cv2.imshow('Resultat',combiner)
    cv2.waitKey(0)


def main():
    path_req=str(input("Chemin d image requete: "))
    dist_dictt = Chercher(rf'{path_req}')
    Affichage(dist_dictt)


if __name__ == '__main__':
    main()