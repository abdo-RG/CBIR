#Importation des bibliothèques
from app import pourcentage
import app
import texture
from texture import texture_classe
import forme
from forme import classe_moment
from glob import glob
from tkinter import filedialog
from click import command
import cv2
import numpy as np
import os.path
import pickle
from scipy.spatial import distance
import time
from tkinter import *
from sympy import im

pathDataset = "./dataset"
pathFichierTrain = "./train"

global_window = Tk()
global_window.geometry('1000x500+100+50')
global_window.title("Moteure de recherche d'image")

global_window.resizable(False,False)
title = Label(global_window,text="MOTEURE DE RECHERCHE D'IMAGE",fg="gold",bg="black",font=("jawal",16,"bold")).pack(fill='x')
F1 = Frame(global_window,width=250,height=700,bg='red').place(x=0,y=30)
L1 = Label(F1,text="Recherche basée sur \n contenu ",fg='black',bg='red',font=('Comic Sans MS',12,"bold")).place(x=20,y=60)
# photo = PhotoImage(file="E:\\galx.png")
# logo = Label(global_window,image=photo).place(x=250,y=30)

def color():
        global img_req_lebel
        global img_req_entry
        global nbr_img_lebel
        global nbr_img_entry
        global chercher_btn
        global Eval_lebel
        global precision_lebel
        global precision_entry
        global rappel_lebel
        global rappel_entry
        global frappel_entry
        global frappel_lebel
        def combine(img_1,img_2):
            h1, w1 = img_1.shape[:2]
            h2, w2 = img_2.shape[:2]

            #create empty matrix
            vis = np.zeros((max(h1, h2), w1+w2,3), np.uint8)

            #combine 2 images
            vis[:h1, :w1,:3] = img_1
            vis[:h2, w1:w1+w2,:3] = img_2
            return vis

        def combinerVertical(img1,img2):
            # combine 2 images same as to concatenate images with two different sizes
            h1, w1 = img1.shape[:2]
            h2, w2 = img2.shape[:2]
            # create empty martrix (Mat)
            res = np.zeros(shape=(h1+h2, max(w1 , w2), 3), dtype=np.uint8)
            # assign BGR values to concatenate images
            for i in range(res.shape[2]):
                # assign img1 colors
                res[:h1, :w1, i] = np.ones([img1.shape[0], img1.shape[1]]) * img1[:, :, i]
                # assign img2 colors
                res[h1:h2+h1, :w2, i] = np.ones([img2.shape[0], img2.shape[1]]) * img2[:, :, i]

            output_img = res.astype('uint8')
            return output_img

        #Calcul de l'histogramme et normalisation connaissant le chemin de l'image

        def Histogramme(chemin):
            #stocker une image X dans image.
            image = cv2.imread(chemin)
            #Calcul d'Histogramme de image
            histogramme = cv2.calcHist([image], [0, 1, 2], None, [8,8,8],[0, 256, 0, 256, 0, 256])
            #Normalisation de notre histogramme est la transformer a un Array de 1 dimension 'flatten()'
            histogramme = cv2.normalize(histogramme, histogramme).flatten()
            return histogramme

        #Creation du fichier pour stockage des descripteurs pickle
        def pickle_hist(fichier,histogramme):   
            pkl=pickle.Pickler(fichier)
            pkl.dump(histogramme)

        #Récupération du descripteur Unpickle
        def unpickle_hist(fichier):   
            Unpkl=pickle.Unpickler(fichier)
            fic=(Unpkl.load())
            return fic

        #Fonction de stockage des histogrammes normalisées
        def Apprentissage():
            #Création du fichier de stockage des histogrammes
            f = open((pathFichierTrain+"/histogramme"+".txt"),'wb')
            listeImage = os.listdir(pathDataset)
            hist_obj = {}
            for image in listeImage:
                histogramme = Histogramme("dataset/"+image)
                hist_obj[image] = histogramme
            pickle_hist(f,hist_obj)
            f.close

        #Fonction de calcul de distance entre deux histogrammes:On utilse la distance 'Hellinger' (distance de Bhattacharyya) '.
        def CalculDistance(hist1,hist2):
            distances=cv2.compareHist(hist1,hist2,cv2.HISTCMP_BHATTACHARYYA)
            return distances

        #Chercher les plus proches voisins
        def RessemblaceImage(cheminImageTest,k):
            listeDistance ={}
            #Calcul de l'histogramme de l'image de test
            hist1 = Histogramme(cheminImageTest)
            hist1 = np.asanyarray(hist1)
            f = open((pathFichierTrain+"/histogramme"+".txt"),"rb")
            list_hist = unpickle_hist(f)
            for key, valeur in list_hist.items():
                valeur = np.asanyarray(valeur)
                CalculDistance(valeur,hist1)
                listeDistance[CalculDistance(valeur,hist1)] = key
            listeDistances = sorted(listeDistance.items(), key=lambda t: t[0])
            f.close
            return(listeDistances[:k])


        def search():
            Apprentissage()
            # print("********************************************************************")
            # print("*                                                                  *")
            # print("*         RECHERCHE D'IMAGE EN UTILISANT L'HISTOGRAMME             *")
            # print("                                                                                         ")
            chemin=chemin_entry.get()
            req = cv2.imread(chemin)
            dsize=(250,250)
            img_req = cv2.resize(req,dsize)
            cv2.imshow('Image requete',img_req)
            # cv2.waitKey()
            k = nbr_img_chrch.get()
            listeImage = RessemblaceImage(chemin,k)


            chemin = chemin.split("/")
            classe = (chemin[len(chemin)-1]).split("_")
            classe = classe[0]
            # print("                                                        ")
            
            # print("                                                        ")
            # print("-------------LISTE des resssemblances---------------")
            # print("                                                        ")
            # print("Images                                 Distance")
            nbTrouve = 0

            rest = []
            resultat = np.zeros((200, 200, 3))
            rest.append(resultat)
            for i in range(len(listeImage)):
                # print(listeImage[i][1],"                         ",listeImage[i][0])
                chmn='dataset/'
                gm=cv2.imread(chmn+listeImage[i][1])
                dsize=(200,200)
                # output = cv2.resize(gm, dsize, interpolation=cv2.INTER_AREA)
                output = cv2.resize(gm, dsize)
                # cv2.imshow('ImageOriginale',output)

                if i==0:
                    rst=output
                elif  i==1:
                    rst=combine(rst,output)
                elif  (i>1 and i<6):

                    rst = combine(rst, output)
                elif  i==6:
                    bst=output
                elif i==7:
                    bst=combine(bst,output)
                elif (i>7 and i<12):
                    bst=combine(bst,output)
                elif i==12:
                    im_3=output
                elif i==13:
                    im_3=combine(im_3,output)
                elif (i>13 and i<18):
                    im_3=combine(im_3,output)


                chaine = listeImage[i][1]
                chaine = chaine.split("_")
                if(classe == chaine[0]):
                    nbTrouve=1+nbTrouve

            if k<=6:
                cv2.imshow("ImagesSimilaires", rst)
            elif k<=12:
                finlRes=combinerVertical(rst,bst)

            elif  k<=18:
                finlRes=combinerVertical(combinerVertical(rst,bst),im_3)
            if k>6:
                cv2.imshow("ImagesSimilaires",finlRes)
            # print("                                                        ")
            # print("-------       EVALUATION     ---------")       
            precision = nbTrouve/k
            rappel = nbTrouve/50
            fmesure = 2/((1/precision)+(1/rappel))
            precision_var.set(precision)
            rappel_var.set(rappel)
            frappel_var.set(fmesure)
            # print("La précision est de = ", precision)
            # print("Le rappel est de = ", rappel)
            # print("La F-mesure est de = ", fmesure)
            cv2.waitKey(0)



        window = Toplevel()
        window.geometry('1000x500+100+50')
        window.title("Moteure de recherche d'image")
        window.config(bg='#80ffff')

        def choisir_fichier():
            ask_file = filedialog.askopenfile()
            pth = ask_file.name
            llst = pth.split('/')
            chemin_entry.set(llst[-2]+'/'+llst[-1])

        img_req_lebel = Label(window,text="Entrer l'image requête :",bg='#80ffff').place(x=20,y=10)
        chemin_entry = StringVar()
        img_req_entry = Entry(window,bg='#ffff00',width=60,textvariable=chemin_entry).place(x=180,y=10)
        img_req_btn = Button(window,text='Choisir fichier',command=choisir_fichier).place(x=560,y=10)
        nbr_img_lebel = Label(window,text='Le nombre des images à cherecher :',bg='#80ffff').place(x=20,y=50)
        nbr_img_chrch = IntVar()
        nbr_img_entry = Entry(window,width=20,textvariable=nbr_img_chrch,bg='yellow').place(x=240,y=50)

        chercher_btn = Button(window,text='Chercher',width=20,command=search).place(x=220,y=90)

        frm_dessous = Frame(window,bg='#808080',height=320,width=1000).place(x=0,y=170)

        Eval_lebel = Label(window,text='EVALUATION',bg='#808080',width=10,font=("jawal",12,"bold")).place(x=450,y=170)

        precision_lebel = Label(window,text='Précision ',bg='#808080').place(x=20,y=195)
        precision_var = IntVar()
        precision_entry = Entry(window,width=20,textvariable=precision_var).place(x=100,y=200)

        rappel_lebel = Label(window,text='Rappel      ',bg='#808080').place(x=20,y=215)
        rappel_var = IntVar()
        rappel_entry = Entry(window,width=20,textvariable=rappel_var).place(x=100,y=220)

        frappel_lebel = Label(window,text='F-mesure ',bg='#808080').place(x=20,y=235)
        frappel_var = IntVar()
        frappel_entry = Entry(window,width=20,textvariable=frappel_var).place(x=100,y=240)

        btn_quit = Button(window,text='Quitter',command=window.destroy).place(x=480,y=470)

        window.mainloop()



color_btn = Button(F1,text='Chercher par couleur',bg='gold',width=20,font=("jawal",12,"bold"),command=color).place(x=15,y=140)

color_btn2 = Button(F1,text='Chercher par texture',bg='gold',width=20,font=("jawal",12,"bold"),command=texture.texture_classe).place(x=15,y=180)

color_btn3 = Button(F1,text='Chercher par forme',bg='gold',width=20,font=("jawal",12,"bold"),command=forme.classe_moment).place(x=15,y=220)

color_btn4 = Button(F1,text='Chercher par pourcentage',bg='gold',width=20,font=("jawal",12,"bold"),command=app.pourcentage).place(x=15,y=260)

btn_quit = Button(global_window,text='Quitter',font=('jawal',16,'bold'),fg='purple',activeforeground='purple',bg='green',cursor='hand2',width=15,command=global_window.quit).place(x=440,y=460)

global_window.mainloop()