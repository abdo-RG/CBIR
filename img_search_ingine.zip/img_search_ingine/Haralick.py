import cv2
from skimage import feature
import os
import pandas as pd
import numpy as np
from tqdm import tqdm
import csv

dataset = 'txtredataset'


def Humom_descrip(image_path:str):
    features = []
    gray_img = cv2.imread(image_path,cv2.IMREAD_GRAYSCALE)
    matCo = feature.graycomatrix(gray_img, [5], [0,np.pi/2,np.pi/4,(np.pi*3)/4], 256,
                         symmetric=True, normed=True)
    features.append(feature.graycoprops(matCo,'energy').flatten())
    features.append(feature.graycoprops(matCo,'contrast').flatten())
    features.append(feature.graycoprops(matCo,'dissimilarity').flatten())
    features.append(feature.graycoprops(matCo,'homogeneity').flatten())
    features.append(feature.graycoprops(matCo,'correlation').flatten())

    return np.array(features).flatten()


def Apprentissage(datasetpath):
    Hu_mom_dict = {}
    for img in tqdm(os.listdir(datasetpath)):
        Hu_mom_dict[img] = Humom_descrip(datasetpath+'/'+img)
        
    df = pd.DataFrame(Hu_mom_dict)
    index_fichier = df.to_csv('Haralick.csv')
    return index_fichier

# Apprentissage(dataset)

df = pd.read_csv('Haralick.csv')

def Chercher(chemin_req):
    dist_dict = {}
    req_histo = Humom_descrip(chemin_req)
    df[chemin_req] = req_histo
    for img in df.columns:
        dist_dict[img]=np.linalg.norm(df[chemin_req]-df[img])/10

    dist_dict = dict(sorted(dist_dict.items(), key=lambda item: item[1]))
    
    return dist_dict


def Affichage(dataset,dist_dict):
    combiner = np.ones((100*2,100*4,3),dtype=np.uint8)
    p_h=0
    p_v=0
    for k in range(8):
        if k < 4 :
            combiner[:100,p_h:p_h+100] = cv2.resize(cv2.imread(dataset+'/'+list(dist_dict.keys())[k+1]),(100,100))
            p_h+=100
        else:
            combiner[100:300,p_v:p_v+100] = cv2.resize(cv2.imread(dataset+'/'+list(dist_dict.keys())[k+1]),(100,100))
            p_v+=100
    img_req = cv2.imread(dataset+'/'+list(dist_dict.keys())[1])
    cv2.imshow('Image_reqeutte',img_req)
    cv2.imshow('Resultat',combiner)
    cv2.waitKey(0)


def main():
    path_dataset=str(input("Chemin du dataset: "))
    path_req=str(input("Chemin d image requete: "))
    dist_dictt = Chercher(rf'{path_req}')
    Affichage(path_dataset,dist_dictt)


if __name__ == '__main__':
    main()
